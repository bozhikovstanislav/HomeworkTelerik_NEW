﻿using System;


namespace OperatorsAndExpression
{
    class OddEvenInteger
    {

         
        
    }
}
