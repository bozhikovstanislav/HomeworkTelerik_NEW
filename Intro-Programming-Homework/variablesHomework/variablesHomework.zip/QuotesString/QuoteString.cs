﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuotesString
{
    class QuoteString
    {
        static void Main(string[] args)
        {
            //Problem 7 Quptes in String

            string qupotes="The \"use\" of quotations cause difficulties.";
            Console.WriteLine(qupotes);
            Console.ReadLine();
        }
    }
}
