﻿using System;


namespace variablesHomework
{
    class DeclareVariables
    {
        static void Main(string[] args)
        {

            //Problem 1. Declare Variables
            byte numberA = 97;
            short numberB = -115;
            uint numberC = 52130;
            int numberD = -10000;
            uint numberE = 4825932;
        }
    }
}
