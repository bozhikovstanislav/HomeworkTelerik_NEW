﻿using System;


namespace FloatDouble
{
    class FloatDaouble
    {
        static void Main(string[] args)
        {

            //Problem 2
            float valueA = 12.345F;
            float valueB = 3456.091F;

            double valueC = 34.567839023;
            double valuseD = 8923.1234857;

            Console.WriteLine(" float ValueA = {0}", valueA);
            Console.WriteLine("float ValueB = {0}", valueB);
            Console.WriteLine("double valueC  = {0}", valueC);
            Console.WriteLine("double valueD = {0}", valuseD);
            Console.ReadLine();
        }
    }
}
