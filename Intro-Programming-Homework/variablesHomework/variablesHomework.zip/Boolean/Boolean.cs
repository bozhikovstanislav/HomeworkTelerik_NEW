﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Boolean
{
    class Boolean
    {
        static void Main(string[] args)
        {
            //Problem 5 boolean Variable
            bool isFmaile = false;

            Console.WriteLine("am I a Fmale ?");
            Console.WriteLine(isFmaile);
            Console.ReadLine();
        }
    }
}
