﻿using System;


namespace Hexadecimal
{
    class Hexadecimal
    {
        static void Main(string[] args)
        {
            //Problem 3

            int hexaNumber = 0xFE;

            Console.WriteLine(hexaNumber);
            Console.ReadLine();
        }
    }
}
