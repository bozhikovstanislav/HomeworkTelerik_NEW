﻿using System;


namespace UnicodChar
{
    class UnicodChar
    {
        static void Main(string[] args)
        {

            //Problem 4 Unicode Character
            decimal valueA = 0x2A;
            char valueB = '\u002A';

            Console.WriteLine(valueA);
            Console.WriteLine(valueB);
            Console.ReadLine();
        }
    }
}
